#!/usr/bin/env python

from math import sqrt
import math
import rospy
from nav_msgs.msg import Odometry
from std_msgs.msg import String
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
import actionlib
from actionlib_msgs.msg import *
from geometry_msgs.msg import Pose, Point, Quaternion

#Moves directly towards target.
#Initially may guess where target is.
class NaiveHunterAI:

    def __init__(self):
        self.t_loc = Point(0,0,0)
        self.h0_loc = None
        self.h1_loc = None
        self.goal_sent = False
        rospy.on_shutdown(self.shutdown)
        self.move_base = actionlib.SimpleActionClient("robot_0/move_base", MoveBaseAction)
        self.move_base1 = actionlib.SimpleActionClient("robot_1/move_base", MoveBaseAction)
        self.move_base.wait_for_server(rospy.Duration(5))
        self.move_base1.wait_for_server(rospy.Duration(5))

        self.h0_sub = rospy.Subscriber('robot_0/base_pose_ground_truth', Odometry, self.h0Callback)
        self.h1_sub = rospy.Subscriber('robot_1/base_pose_ground_truth', Odometry, self.h1Callback)
        self.d_sub = rospy.Subscriber('dist_rep', String, self.distCallback)

    def distCallback(self,data):
        dList = data.data.split()
        self.d0 = float(dList[0])
        self.d1 = float(dList[1])
        pon = self.triangulate()
        (p1,p2) = 0, 0
        if pon == None:
            return

        (p1,p2) = pon
        #Send One Robot To each location
        self.goal_sent = True
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = 'map'
        goal.target_pose.header.stamp = rospy.Time.now()
        goal.target_pose.pose = Pose(p2, Quaternion(0, 0, 0, 1))

        goal1 = MoveBaseGoal()
        goal1.target_pose.header.frame_id = 'map'
        goal1.target_pose.header.stamp = rospy.Time.now()
        goal1.target_pose.pose = Pose(p1, Quaternion(0, 0, 0, 1))
        # Start moving
        self.move_base.send_goal(goal)
        self.move_base1.send_goal(goal1)

    #needs a fix to not just take in tuple, point for p1, p2
    def distance(self, p1,p2):
        return math.sqrt((p1.x-p2.x)**2 + (p1.y-p2.y)**2)

    def shutdown(self):
        if self.goal_sent:
            self.move_base.cancel_goal()
        rospy.loginfo("Stop")

    def h0Callback(self,data):
        self.h0_loc = data.pose.pose.position

    def h1Callback(self,data):
        self.h1_loc = data.pose.pose.position

    def dist(self, P0, P1):
        return sqrt((P1.x - P0.x)**2 + (P1.y - P0.y)**2)

    def triangulate(self):
        if None in [self.h0_loc,self.h1_loc]:
            return
        
        return self.IntersectPoints(self.h0_loc, self.h1_loc, self.d0, self.d1)

    def IntersectPoints(self, P0c, P1c, r0, r1):
        P0 = complex(P0c.x, P0c.y)
        P1 = complex(P1c.y, P1c.y)

        # d = distance
        d = sqrt((P1.real - P0.real)**2 + (P1.imag - P0.imag)**2)
        # n**2 in Python means "n to the power of 2"
        # note: d = a + b

        if d > (r0 + r1):
            return None
        elif d < abs(r0 - r1):
            #the bots are 
            return None
        elif d == 0:
            return None
        else:
            a = (r0**2 - r1**2 + d**2) / (2 * d)
            b = d - a
            h = sqrt(r0**2 - a**2)
            P2 = P0 + a * (P1 - P0) / d

            i1x = P2.real + h * (P1.imag - P0.imag) / d
            i1y = P2.imag - h * (P1.real - P0.real) / d
            i2x = P2.real - h * (P1.imag - P0.imag) / d
            i2y = P2.imag + h * (P1.real - P0.real) / d

            i1 = Point(i1x, i1y, 0)
            i2 = Point(i2x, i2y, 0)

            return [i1, i2]

if __name__ == '__main__':
    try:
        rospy.init_node('naive', anonymous=False)
        ai = NaiveHunterAI()
        rospy.spin()
    except rospy.ROSInterruptException:
        rospy.loginfo("Ctrl-C caught. Quitting")
