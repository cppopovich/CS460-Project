##Launch Files
Launch dense-multi.....launch to run stage with multiple robots on a dense map  
Launch naive.launch to run the prey controller and the naive pathfinder. The naive pathfinder triangulation does some wierd stuff, so it may be wrong.  

##World Files
There are severa new maps, all the same size. They need yaml and world files. You should be able to copy dense.yaml and dense.world, and just change the image name.  
